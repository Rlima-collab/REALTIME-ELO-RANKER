export interface MatchResult {
  winner: {
    id: string;
    rank: number;
  };
  loser: {
    id: string;
    rank: number;
  };
}
