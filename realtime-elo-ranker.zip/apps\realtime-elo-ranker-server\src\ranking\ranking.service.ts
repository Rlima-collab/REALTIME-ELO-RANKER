import { Injectable, OnModuleInit } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Player } from '../player/entities/player.entity';
import { RankingUpdate } from './interfaces/ranking-event.interface';

@Injectable()
export class RankingService implements OnModuleInit {
  // Cache en mémoire pour le classement (singleton)
  private rankingCache: Map<string, number> = new Map();

  constructor(
    private readonly eventEmitter: EventEmitter2,
    @InjectRepository(Player)
    private readonly playerRepository: Repository<Player>,
  ) {}

  async onModuleInit() {
    // Initialiser le cache avec les données de la base
    await this.initializeCache();
  }

  private async initializeCache() {
    try {
      const players = await this.playerRepository.find();
      players.forEach((player) => {
        this.rankingCache.set(player.id, player.rank);
      });
    } catch {
      // La table n'existe pas encore, c'est normal au premier démarrage
      console.log('Initializing ranking cache - no existing players');
    }
  }

  /**
   * Ajoute un joueur au cache de classement
   */
  addPlayer(player: Player): void {
    this.rankingCache.set(player.id, player.rank);
    this.emitRankingUpdate(player);
  }

  /**
   * Met à jour le rang d'un joueur dans le cache et émet un événement
   */
  updatePlayerRank(playerId: string, newRank: number): void {
    this.rankingCache.set(playerId, Math.round(newRank));
    this.emitRankingUpdate({ id: playerId, rank: Math.round(newRank) });
  }

  /**
   * Récupère le rang d'un joueur depuis le cache
   */
  getPlayerRank(playerId: string): number | undefined {
    return this.rankingCache.get(playerId);
  }

  /**
   * Récupère le classement complet trié par rang décroissant
   */
  getRanking(): { id: string; rank: number }[] {
    const ranking: { id: string; rank: number }[] = [];
    this.rankingCache.forEach((rank, id) => {
      ranking.push({ id, rank });
    });
    return ranking.sort((a, b) => b.rank - a.rank);
  }

  /**
   * Calcule la moyenne des rangs pour le rang initial d'un nouveau joueur
   */
  async getAverageRank(): Promise<number> {
    if (this.rankingCache.size === 0) {
      return 1000; // Rang par défaut
    }
    let total = 0;
    this.rankingCache.forEach((rank) => {
      total += rank;
    });
    return total / this.rankingCache.size;
  }

  /**
   * Vérifie si un joueur existe dans le cache
   */
  hasPlayer(playerId: string): boolean {
    return this.rankingCache.has(playerId);
  }

  /**
   * Émet un événement de mise à jour du classement
   */
  private emitRankingUpdate(player: { id: string; rank: number }): void {
    const event: RankingUpdate = {
      type: 'RankingUpdate',
      player: {
        id: player.id,
        rank: player.rank,
      },
    };
    this.eventEmitter.emit('ranking.update', event);
  }
}
