# Realtime ELO Ranker - Simulator (bonus)

This small app posts matches to the server to simulate activity.

Usage:
- Ensure the server is running on http://localhost:8080 (or set SERVER_URL env var).
- `pnpm --filter ./apps/realtime-elo-ranker-simulator run once` to post a few matches.
- `pnpm --filter ./apps/realtime-elo-ranker-simulator run dev` to run continuously.

It ships with small unit tests for the simulator logic (no server calls).
