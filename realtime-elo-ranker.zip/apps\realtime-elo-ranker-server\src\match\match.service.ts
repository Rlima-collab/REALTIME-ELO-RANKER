import { Injectable, UnprocessableEntityException } from '@nestjs/common';
import { CreateMatchDto } from './dto/create-match.dto';
import { MatchResult } from './interfaces/match-result.interface';
import { calculateMatchResult } from './elo.utils';
import { PlayerService } from '../player/player.service';
import { RankingService } from '../ranking/ranking.service';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Match } from './entities/match.entity';

@Injectable()
export class MatchService {
  constructor(
    private readonly playerService: PlayerService,
    private readonly rankingService: RankingService,
    @InjectRepository(Match)
    private readonly matchRepository: Repository<Match>,
  ) {}

  async processMatch(createMatchDto: CreateMatchDto): Promise<MatchResult> {
    const { winner, loser, draw } = createMatchDto;

    // Vérifier que les deux joueurs existent
    const winnerPlayer = await this.playerService.findOne(winner);
    const loserPlayer = await this.playerService.findOne(loser);

    if (!winnerPlayer) {
      throw new UnprocessableEntityException({
        code: 422,
        message: `Le joueur '${winner}' n'existe pas`,
      });
    }

    if (!loserPlayer) {
      throw new UnprocessableEntityException({
        code: 422,
        message: `Le joueur '${loser}' n'existe pas`,
      });
    }

    // Récupérer les rangs actuels depuis le cache
    const winnerRank = this.rankingService.getPlayerRank(winner) ?? winnerPlayer.rank;
    const loserRank = this.rankingService.getPlayerRank(loser) ?? loserPlayer.rank;

    // Calculer les nouveaux rangs
    const { newWinnerRank, newLoserRank } = calculateMatchResult(
      winnerRank,
      loserRank,
      draw ?? false,
    );

    // Mettre à jour les rangs en base de données
    await this.playerService.updateRank(winner, newWinnerRank);
    await this.playerService.updateRank(loser, newLoserRank);

    // Mettre à jour le cache et émettre les événements
    this.rankingService.updatePlayerRank(winner, newWinnerRank);
    this.rankingService.updatePlayerRank(loser, newLoserRank);

    // Persister l'historique du match
    const matchEntity = this.matchRepository.create({
      winner,
      loser,
      draw: draw ?? false,
      winnerRank: newWinnerRank,
      loserRank: newLoserRank,
    });
    await this.matchRepository.save(matchEntity);

    return {
      winner: {
        id: winner,
        rank: newWinnerRank,
      },
      loser: {
        id: loser,
        rank: newLoserRank,
      },
    };
  }

  async getHistory(): Promise<Match[]> {
    return this.matchRepository.find({ order: { createdAt: 'DESC' } });
  }
}
