(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_265c9a2e._.js",
  "static/chunks/b5d7d_next_dist_compiled_react-dom_e2c4ff07._.js",
  "static/chunks/b5d7d_next_dist_compiled_next-devtools_index_9693f825.js",
  "static/chunks/b5d7d_next_dist_compiled_2edf9df4._.js",
  "static/chunks/b5d7d_next_dist_client_e0517feb._.js",
  "static/chunks/b5d7d_next_dist_0fbe6411._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
