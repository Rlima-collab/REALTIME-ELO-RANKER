export interface RankingUpdate {
  type: 'RankingUpdate';
  player: {
    id: string;
    rank: number;
  };
}

export interface RankingError {
  type: 'Error';
  code: number;
  message: string;
}

export type RankingEvent = RankingUpdate | RankingError;
