import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { App } from 'supertest/types';
import { AppModule } from './../src/app.module';

describe('API E2E Tests', () => {
  let app: INestApplication<App>;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  describe('Player API', () => {
    const unique = Date.now().toString();

    it('POST /api/player - should create a player', () => {
      const id = `testPlayer1-${unique}`;
      return request(app.getHttpServer())
        .post('/api/player')
        .send({ id })
        .expect(201)
        .expect((res) => {
          expect(res.body.id).toBe(id);
          expect(res.body.rank).toBeDefined();
        });
    });

    it('POST /api/player - should return 400 for invalid id', () => {
      return request(app.getHttpServer())
        .post('/api/player')
        .send({ id: '' })
        .expect(400);
    });

    it('POST /api/player - should return 409 for duplicate player', async () => {
      const id = `duplicatePlayer-${unique}`;
      // Create first player
      await request(app.getHttpServer())
        .post('/api/player')
        .send({ id })
        .expect(201);

      // Try to create duplicate
      return request(app.getHttpServer())
        .post('/api/player')
        .send({ id })
        .expect(409);
    });
  });

  describe('Ranking API', () => {
    it('GET /api/ranking - should return ranking after players exist', async () => {
      // First create some players
      await request(app.getHttpServer())
        .post('/api/player')
        .send({ id: 'rankPlayer1' });

      return request(app.getHttpServer())
        .get('/api/ranking')
        .expect(200)
        .expect((res) => {
          expect(Array.isArray(res.body)).toBe(true);
          expect(res.body.length).toBeGreaterThan(0);
        });
    });
  });

  describe('Match API', () => {
    it('POST /api/match - should process a match', async () => {
      // Create two players first
      await request(app.getHttpServer())
        .post('/api/player')
        .send({ id: 'matchPlayer1' });
      await request(app.getHttpServer())
        .post('/api/player')
        .send({ id: 'matchPlayer2' });

      await request(app.getHttpServer())
        .post('/api/match')
        .send({ winner: 'matchPlayer1', loser: 'matchPlayer2' })
        .expect(201);

      // Check match history contains the match
      const history = await request(app.getHttpServer()).get('/api/match').expect(200);
      expect(Array.isArray(history.body)).toBe(true);
      expect(history.body.length).toBeGreaterThan(0);
      expect(history.body[0].winner).toBeDefined();
    });

    it('POST /api/match - should return 422 for non-existent player', () => {
      return request(app.getHttpServer())
        .post('/api/match')
        .send({ winner: 'nonexistent1', loser: 'nonexistent2' })
        .expect(422);
    });

    it('POST /api/match - should handle draw correctly', async () => {
      // Create two players
      await request(app.getHttpServer())
        .post('/api/player')
        .send({ id: 'drawPlayer1' });
      await request(app.getHttpServer())
        .post('/api/player')
        .send({ id: 'drawPlayer2' });

      return request(app.getHttpServer())
        .post('/api/match')
        .send({ winner: 'drawPlayer1', loser: 'drawPlayer2', draw: true })
        .expect(201);
    });
  });
});
