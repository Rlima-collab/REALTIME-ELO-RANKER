import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { PlayerModule } from './player/player.module';
import { MatchModule } from './match/match.module';
import { RankingModule } from './ranking/ranking.module';
import { Player } from './player/entities/player.entity';
import { Match } from './match/entities/match.entity';

@Module({
  imports: [
    // Configuration TypeORM avec sqljs (JavaScript pur, pas de bindings natifs)
    TypeOrmModule.forRoot({
      type: 'sqljs',
      location: 'db.sqlite',
      autoSave: true,
      entities: [Player, Match],
      synchronize: true, // Auto-sync en développement
    }),
    // Module EventEmitter pour les événements temps réel
    EventEmitterModule.forRoot(),
    // Modules métier
    PlayerModule,
    MatchModule,
    RankingModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
