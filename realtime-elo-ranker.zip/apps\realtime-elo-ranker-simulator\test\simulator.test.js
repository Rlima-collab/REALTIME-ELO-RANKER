const { pickPair, buildMatchBody } = require('../lib/simulator');

describe('simulator', () => {
  test('pickPair throws when not enough players', () => {
    expect(() => pickPair([])).toThrow('Not enough players');
  });

  test('pickPair returns two different players', () => {
    const players = [{ id: 'a' }, { id: 'b' }, { id: 'c' }];
    const [x, y] = pickPair(players);
    expect(x).not.toBe(y);
    expect(players).toContain(x);
    expect(players).toContain(y);
  });

  test('buildMatchBody produces valid body', () => {
    const a = { id: 'a' };
    const b = { id: 'b' };
    const body = buildMatchBody(a, b);
    expect(body).toHaveProperty('draw');
    if (body.draw) {
      // Even draws should include the two players
      expect(body).toHaveProperty('winner');
      expect(body).toHaveProperty('loser');
      expect([a.id, b.id]).toContain(body.winner);
      expect([a.id, b.id]).toContain(body.loser);
    } else {
      expect(body).toHaveProperty('winner');
      expect(body).toHaveProperty('loser');
      expect([a.id, b.id]).toContain(body.winner);
    }
  });
});
