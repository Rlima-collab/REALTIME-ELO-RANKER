const http = require('http');
function getPlayers() {
  return new Promise((resolve, reject) => {
    http.get({ hostname: 'localhost', port: 8080, path: '/api/ranking' }, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d).map(p => p.id)); } catch (e) { reject(e); } });
    }).on('error', reject);
  });
}
function postMatch(winner, loser) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ winner, loser, draw: false });
    const req = http.request({ hostname: 'localhost', port: 8080, path: '/api/match', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } }, (res) => {
      let d=''; res.on('data', c=>d+=c); res.on('end', ()=>resolve({status: res.statusCode, body: d}));
    });
    req.on('error', reject); req.write(body); req.end();
  });
}
(async () => {
  const count = parseInt(process.argv[2] || '100', 10);
  console.log('Simulation count:', count);
  const players = await getPlayers();
  if (!players || players.length < 2) { console.error('Not enough players'); process.exit(1); }
  for (let i = 0; i < count; i++) {
    const a = players[Math.floor(Math.random() * players.length)];
    let b = players[Math.floor(Math.random() * players.length)]; while (b === a) b = players[Math.floor(Math.random() * players.length)];
    const winner = Math.random() < 0.5 ? a : b; const loser = winner === a ? b : a;
    try {
      const r = await postMatch(winner, loser);
      process.stdout.write('.');
    } catch (e) {
      process.stdout.write('E');
    }
    await new Promise(r => setTimeout(r, 25));
  }
  console.log('\nSimulation done');
})();