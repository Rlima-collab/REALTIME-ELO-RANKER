(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_6e25520c._.js",
  "static/chunks/[root-of-the-server]__78ae1ae3._.js",
  "static/chunks/[root-of-the-server]__ba86e640._.css"
],
    source: "dynamic"
});
