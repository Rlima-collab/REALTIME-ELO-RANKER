import { Test, TestingModule } from '@nestjs/testing';
import { UnprocessableEntityException } from '@nestjs/common';
import { MatchService } from './match.service';
import { PlayerService } from '../player/player.service';
import { RankingService } from '../ranking/ranking.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Match } from './entities/match.entity';
import { Repository } from 'typeorm';

describe('MatchService', () => {
  let service: MatchService;
  let playerService: PlayerService;
  let rankingService: RankingService;
  // `matchRepo` is a mocked repository in tests, use `any` to allow Jest mock helpers
  let matchRepo: any;

  const mockPlayerService = {
    findOne: jest.fn(),
    updateRank: jest.fn(),
  };

  const mockRankingService = {
    getPlayerRank: jest.fn(),
    updatePlayerRank: jest.fn(),
  };

  const mockMatchRepository = {
    create: jest.fn((dto) => dto),
    save: jest.fn(),
    find: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MatchService,
        {
          provide: PlayerService,
          useValue: mockPlayerService,
        },
        {
          provide: RankingService,
          useValue: mockRankingService,
        },
        {
          provide: getRepositoryToken(Match),
          useValue: mockMatchRepository,
        },
      ],
    }).compile();

    service = module.get<MatchService>(MatchService);
    playerService = module.get<PlayerService>(PlayerService);
    rankingService = module.get<RankingService>(RankingService);
    matchRepo = module.get(getRepositoryToken(Match));
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('processMatch', () => {
    it('should process a match and update ranks', async () => {
      const winner = { id: 'player1', rank: 1000 };
      const loser = { id: 'player2', rank: 1000 };

      mockPlayerService.findOne
        .mockResolvedValueOnce(winner)
        .mockResolvedValueOnce(loser);
      mockRankingService.getPlayerRank
        .mockReturnValueOnce(1000)
        .mockReturnValueOnce(1000);
      mockPlayerService.updateRank.mockResolvedValue({});

      const result = await service.processMatch({
        winner: 'player1',
        loser: 'player2',
      });

      expect(result.winner.id).toBe('player1');
      expect(result.loser.id).toBe('player2');
      expect(result.winner.rank).toBeGreaterThan(1000);
      expect(result.loser.rank).toBeLessThan(1000);
      expect(mockRankingService.updatePlayerRank).toHaveBeenCalledTimes(2);
    });

    it('should throw UnprocessableEntityException if winner not found', async () => {
      mockPlayerService.findOne.mockResolvedValueOnce(null);

      await expect(
        service.processMatch({ winner: 'nonexistent', loser: 'player2' }),
      ).rejects.toThrow(UnprocessableEntityException);
    });

    it('should throw UnprocessableEntityException if loser not found', async () => {
      mockPlayerService.findOne
        .mockResolvedValueOnce({ id: 'player1', rank: 1000 })
        .mockResolvedValueOnce(null);

      await expect(
        service.processMatch({ winner: 'player1', loser: 'nonexistent' }),
      ).rejects.toThrow(UnprocessableEntityException);
    });

    it('should handle draw correctly', async () => {
      const winner = { id: 'player1', rank: 1200 };
      const loser = { id: 'player2', rank: 800 };

      mockPlayerService.findOne
        .mockResolvedValueOnce(winner)
        .mockResolvedValueOnce(loser);
      mockRankingService.getPlayerRank
        .mockReturnValueOnce(1200)
        .mockReturnValueOnce(800);
      mockPlayerService.updateRank.mockResolvedValue({});
      matchRepo.save.mockResolvedValue({ id: 1 });

      const result = await service.processMatch({
        winner: 'player1',
        loser: 'player2',
        draw: true,
      });

      // In a draw, higher ranked player should lose points
      expect(result.winner.rank).toBeLessThan(1200);
      // Lower ranked player should gain points
      expect(result.loser.rank).toBeGreaterThan(800);
      // Match history saved
      expect(matchRepo.create).toHaveBeenCalled();
      expect(matchRepo.save).toHaveBeenCalled();
    });

    it('should return history from repository', async () => {
      const history = [{ id: 1, winner: 'a' }];
      matchRepo.find.mockResolvedValue(history);

      const res = await service.getHistory();
      expect(res).toBe(history);
      expect(matchRepo.find).toHaveBeenCalled();
    });
  });
});
