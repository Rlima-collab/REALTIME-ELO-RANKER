import {
  calculateWinProbability,
  calculateNewRank,
  calculateMatchResult,
} from './elo.utils';

describe('ELO Utils', () => {
  describe('calculateWinProbability', () => {
    it('should return ~0.5 for equal ranks', () => {
      const probability = calculateWinProbability(1000, 1000);
      expect(probability).toBeCloseTo(0.5, 2);
    });

    it('should return higher probability for higher ranked player', () => {
      const probability = calculateWinProbability(1200, 1000);
      expect(probability).toBeGreaterThan(0.5);
    });

    it('should return lower probability for lower ranked player', () => {
      const probability = calculateWinProbability(1000, 1200);
      expect(probability).toBeLessThan(0.5);
    });

    it('should calculate correctly for 400 point difference', () => {
      // With 400 point difference, the stronger player should have ~91% win rate
      const strongerProbability = calculateWinProbability(1400, 1000);
      expect(strongerProbability).toBeCloseTo(0.91, 1);

      const weakerProbability = calculateWinProbability(1000, 1400);
      expect(weakerProbability).toBeCloseTo(0.09, 1);
    });

    it('should have complementary probabilities', () => {
      const p1 = calculateWinProbability(1200, 1000);
      const p2 = calculateWinProbability(1000, 1200);
      expect(p1 + p2).toBeCloseTo(1, 5);
    });
  });

  describe('calculateNewRank', () => {
    it('should increase rank for winner', () => {
      const newRank = calculateNewRank(1000, 1000, 1); // Win
      expect(newRank).toBeGreaterThan(1000);
    });

    it('should decrease rank for loser', () => {
      const newRank = calculateNewRank(1000, 1000, 0); // Loss
      expect(newRank).toBeLessThan(1000);
    });

    it('should keep rank same for draw between equal players', () => {
      const newRank = calculateNewRank(1000, 1000, 0.5); // Draw
      expect(newRank).toBe(1000);
    });

    it('should give more points for upset victory', () => {
      // Lower ranked player wins against higher ranked
      const upsetWin = calculateNewRank(1000, 1200, 1);
      const expectedWin = calculateNewRank(1200, 1000, 1);
      
      // Upset should give more points than expected win
      expect(upsetWin - 1000).toBeGreaterThan(expectedWin - 1200);
    });
  });

  describe('calculateMatchResult', () => {
    it('should correctly calculate for a win', () => {
      const result = calculateMatchResult(1000, 1000, false);
      
      expect(result.newWinnerRank).toBeGreaterThan(1000);
      expect(result.newLoserRank).toBeLessThan(1000);
    });

    it('should be zero-sum (total points preserved)', () => {
      const initialTotal = 1000 + 1000;
      const result = calculateMatchResult(1000, 1000, false);
      const finalTotal = result.newWinnerRank + result.newLoserRank;
      
      expect(finalTotal).toBe(initialTotal);
    });

    it('should handle draw correctly', () => {
      const result = calculateMatchResult(1200, 800, true);
      
      // Higher ranked player should lose points in a draw
      expect(result.newWinnerRank).toBeLessThan(1200);
      // Lower ranked player should gain points in a draw
      expect(result.newLoserRank).toBeGreaterThan(800);
    });

    it('should preserve total points in a draw', () => {
      const initialTotal = 1200 + 800;
      const result = calculateMatchResult(1200, 800, true);
      const finalTotal = result.newWinnerRank + result.newLoserRank;
      
      expect(finalTotal).toBe(initialTotal);
    });

    it('should match expected ELO calculation (1200 vs 800)', () => {
      // With 400 point difference:
      // Win probability for 1200: 1 / (1 + 10^((800-1200)/400)) = 1 / (1 + 0.1) ≈ 0.909
      // Win probability for 800: 1 - 0.909 ≈ 0.091
      // Winner gain: K * (1 - 0.909) = 32 * 0.091 ≈ 3
      // Loser loss: K * (0 - 0.091) = 32 * -0.091 ≈ -3
      const result = calculateMatchResult(1200, 800, false);
      
      // Verify zero-sum property
      expect(result.newWinnerRank + result.newLoserRank).toBe(2000);
      // Winner should gain a small amount (expected win)
      expect(result.newWinnerRank).toBeGreaterThan(1200);
      // Loser should lose same amount
      expect(result.newLoserRank).toBeLessThan(800);
    });
  });
});
