#!/usr/bin/env node
const axios = require('axios');
const yargs = require('yargs');
const { pickPair, buildMatchBody } = require('./lib/simulator');

const argv = yargs(process.argv.slice(2)).command('once', 'Run one batch of matches').command('dev', 'Run continuously').argv;
const SERVER = process.env.SERVER_URL || 'http://localhost:8080';

async function getPlayers() {
  const res = await axios.get(`${SERVER}/api/ranking`);
  // server returns items with `id` and `rank`
  return res.data.map(p => ({ id: p.id, rank: p.rank }));
}

async function postMatch(body) {
  return axios.post(`${SERVER}/api/match`, body);
}

async function runOnce(count = 5) {
  const players = await getPlayers();
  if (players.length < 2) {
    console.error('Not enough players to simulate. Create players first.');
    return;
  }
  for (let i = 0; i < count; i++) {
    const [a, b] = pickPair(players);
    const body = buildMatchBody(a, b);
    try {
      await postMatch(body);
      console.log('Posted match', body);
    } catch (err) {
      console.error('Failed to post match', err.message);
    }
  }
}

async function runDev(interval = 1000) {
  while (true) {
    await runOnce(1);
    await new Promise(r => setTimeout(r, interval));
  }
}

if (argv._ && argv._.length > 0 && argv._[0] === 'once') {
  runOnce().catch(err => { console.error(err); process.exit(1); });
} else if (argv._ && argv._.length > 0 && argv._[0] === 'dev') {
  runDev().catch(err => { console.error(err); process.exit(1); });
} else {
  console.log('Usage: node index.js once|dev');
}
