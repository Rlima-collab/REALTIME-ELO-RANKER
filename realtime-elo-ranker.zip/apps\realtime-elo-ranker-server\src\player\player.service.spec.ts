import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BadRequestException, ConflictException } from '@nestjs/common';
import { PlayerService } from './player.service';
import { Player } from './entities/player.entity';
import { RankingService } from '../ranking/ranking.service';

describe('PlayerService', () => {
  let service: PlayerService;
  let repository: Repository<Player>;
  let rankingService: RankingService;

  const mockRepository = {
    findOne: jest.fn(),
    find: jest.fn(),
    create: jest.fn(),
    save: jest.fn(),
    update: jest.fn(),
  };

  const mockRankingService = {
    getAverageRank: jest.fn(),
    addPlayer: jest.fn(),
    updatePlayerRank: jest.fn(),
    getPlayerRank: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PlayerService,
        {
          provide: getRepositoryToken(Player),
          useValue: mockRepository,
        },
        {
          provide: RankingService,
          useValue: mockRankingService,
        },
      ],
    }).compile();

    service = module.get<PlayerService>(PlayerService);
    repository = module.get<Repository<Player>>(getRepositoryToken(Player));
    rankingService = module.get<RankingService>(RankingService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('create', () => {
    it('should create a new player with default rank', async () => {
      const dto = { id: 'player1' };
      const player = { id: 'player1', rank: 1000 };

      mockRepository.findOne.mockResolvedValue(null);
      mockRankingService.getAverageRank.mockResolvedValue(1000);
      mockRepository.create.mockReturnValue(player);
      mockRepository.save.mockResolvedValue(player);

      const result = await service.create(dto);

      expect(result).toEqual(player);
      expect(mockRankingService.addPlayer).toHaveBeenCalledWith(player);
    });

    it('should throw BadRequestException for empty id', async () => {
      const dto = { id: '' };

      await expect(service.create(dto)).rejects.toThrow(BadRequestException);
    });

    it('should throw ConflictException if player exists', async () => {
      const dto = { id: 'player1' };
      const existingPlayer = { id: 'player1', rank: 1000 };

      mockRepository.findOne.mockResolvedValue(existingPlayer);

      await expect(service.create(dto)).rejects.toThrow(ConflictException);
    });

    it('should use average rank for new player', async () => {
      const dto = { id: 'player1' };
      const averageRank = 1150;
      const player = { id: 'player1', rank: averageRank };

      mockRepository.findOne.mockResolvedValue(null);
      mockRankingService.getAverageRank.mockResolvedValue(averageRank);
      mockRepository.create.mockReturnValue(player);
      mockRepository.save.mockResolvedValue(player);

      const result = await service.create(dto);

      expect(result.rank).toBe(averageRank);
    });
  });

  describe('findOne', () => {
    it('should return a player if found', async () => {
      const player = { id: 'player1', rank: 1000 };
      mockRepository.findOne.mockResolvedValue(player);

      const result = await service.findOne('player1');

      expect(result).toEqual(player);
    });

    it('should return null if player not found', async () => {
      mockRepository.findOne.mockResolvedValue(null);

      const result = await service.findOne('nonexistent');

      expect(result).toBeNull();
    });
  });

  describe('updateRank', () => {
    it('should update player rank', async () => {
      const player = { id: 'player1', rank: 1100 };
      mockRepository.update.mockResolvedValue({ affected: 1 });
      mockRepository.findOne.mockResolvedValue(player);

      const result = await service.updateRank('player1', 1100);

      expect(result.rank).toBe(1100);
      expect(mockRepository.update).toHaveBeenCalledWith('player1', { rank: 1100 });
    });
  });
});
