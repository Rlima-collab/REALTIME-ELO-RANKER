import { Controller, Post, Body, Get } from '@nestjs/common';
import { MatchService } from './match.service';
import { CreateMatchDto } from './dto/create-match.dto';
import { MatchResult } from './interfaces/match-result.interface';

@Controller('api/match')
export class MatchController {
  constructor(private readonly matchService: MatchService) {}

  @Post()
  async processMatch(@Body() createMatchDto: CreateMatchDto): Promise<MatchResult> {
    return this.matchService.processMatch(createMatchDto);
  }

  @Get()
  async getHistory() {
    return this.matchService.getHistory();
  }
}
