const http = require('http');
const fs = require('fs');
const expectedEvents = parseInt(process.argv[2] || '200', 10);
const timeoutMs = parseInt(process.argv[3] || '30000', 10);
const out = '.tmp/sse.log';
let received = 0;
let buffer = '';
const req = http.request({ hostname: 'localhost', port: 8080, path: '/api/ranking/events', method: 'GET', headers: { Accept: 'text/event-stream' } }, (res) => {
  res.setEncoding('utf8');
  res.on('data', (chunk) => {
    buffer += chunk;
    let parts = buffer.split('\n\n');
    while (parts.length > 1) {
      const event = parts.shift();
      buffer = parts.join('\n\n');
      fs.appendFileSync(out, event + '\n\n');
      received += (event.match(/data:/g) || []).length || 1;
      if (received >= expectedEvents) {
        console.log('received target events', received);
        process.exit(0);
      }
    }
  });
  res.on('end', () => { console.log('SSE connection ended'); process.exit(0); });
});
req.on('error', (e) => { console.error('SSE err', e.message); process.exit(1); });
req.end();
setTimeout(() => { console.log('timeout, received', received); process.exit(0); }, timeoutMs);
console.log('SSE listener started, will stop after', expectedEvents, 'events or', timeoutMs, 'ms');
