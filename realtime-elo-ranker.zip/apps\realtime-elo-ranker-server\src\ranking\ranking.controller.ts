import { Controller, Get, Sse, NotFoundException, MessageEvent } from '@nestjs/common';
import { Observable, Subject, map, filter } from 'rxjs';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { RankingService } from './ranking.service';
import { RankingUpdate } from './interfaces/ranking-event.interface';

@Controller('api/ranking')
export class RankingController {
  private rankingSubject = new Subject<RankingUpdate>();

  constructor(
    private readonly rankingService: RankingService,
    private readonly eventEmitter: EventEmitter2,
  ) {
    // S'abonner aux événements de mise à jour du classement
    this.eventEmitter.on('ranking.update', (event: RankingUpdate) => {
      this.rankingSubject.next(event);
    });
  }

  @Get()
  getRanking(): { id: string; rank: number }[] {
    const ranking = this.rankingService.getRanking();
    if (ranking.length === 0) {
      throw new NotFoundException({
        code: 404,
        message: "Le classement n'est pas disponible car aucun joueur n'existe",
      });
    }
    return ranking;
  }

  @Sse('events')
  subscribeToRankingEvents(): Observable<MessageEvent> {
    return this.rankingSubject.asObservable().pipe(
      filter((event): event is RankingUpdate => event !== null),
      map((event: RankingUpdate): MessageEvent => ({
        data: event,
      })),
    );
  }
}
