import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class Match {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  winner: string;

  @Column()
  loser: string;

  @Column({ default: false })
  draw: boolean;

  @Column({ type: 'integer' })
  winnerRank: number;

  @Column({ type: 'integer' })
  loserRank: number;

  @CreateDateColumn({ type: 'datetime' })
  createdAt: Date;
}
