import { Injectable, BadRequestException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Player } from './entities/player.entity';
import { CreatePlayerDto } from './dto/create-player.dto';
import { RankingService } from '../ranking/ranking.service';

@Injectable()
export class PlayerService {
  constructor(
    @InjectRepository(Player)
    private readonly playerRepository: Repository<Player>,
    private readonly rankingService: RankingService,
  ) {}

  async create(createPlayerDto: CreatePlayerDto): Promise<Player> {
    const { id } = createPlayerDto;

    // Validation de l'ID
    if (!id || id.trim() === '') {
      throw new BadRequestException({
        code: 400,
        message: "L'identifiant du joueur n'est pas valide",
      });
    }

    // Vérifier si le joueur existe déjà
    const existingPlayer = await this.playerRepository.findOne({ where: { id } });
    if (existingPlayer) {
      throw new ConflictException({
        code: 409,
        message: 'Le joueur existe déjà',
      });
    }

    // Calculer le rang initial (moyenne des rangs existants)
    const averageRank = await this.rankingService.getAverageRank();
    const initialRank = averageRank || 1000;

    // Créer le joueur
    const player = this.playerRepository.create({
      id,
      rank: Math.round(initialRank),
    });

    const savedPlayer = await this.playerRepository.save(player);

    // Ajouter le joueur au cache de classement
    this.rankingService.addPlayer(savedPlayer);

    return savedPlayer;
  }

  async findOne(id: string): Promise<Player | null> {
    return this.playerRepository.findOne({ where: { id } });
  }

  async findAll(): Promise<Player[]> {
    return this.playerRepository.find();
  }

  async updateRank(id: string, newRank: number): Promise<Player> {
    await this.playerRepository.update(id, { rank: Math.round(newRank) });
    const player = await this.findOne(id);
    if (!player) {
      throw new Error(`Player ${id} not found`);
    }
    return player;
  }
}
