/**
 * Calcul du classement Elo
 * Formule: Rn = Ro + K * (W - We)
 * 
 * Rn: Nouveau classement
 * Ro: Ancien classement
 * K: Coefficient de pondération (32 par défaut)
 * W: Résultat du match (1 victoire, 0.5 égalité, 0 défaite)
 * We: Probabilité de victoire
 */

const K_FACTOR = 32; // Coefficient de sensibilité

/**
 * Calcule la probabilité de victoire d'un joueur
 * Formule: We = 1 / (1 + 10^((Rh - Rl) / 400))
 * 
 * @param playerRank - Rang du joueur
 * @param opponentRank - Rang de l'adversaire
 * @returns Probabilité de victoire (entre 0 et 1)
 */
export function calculateWinProbability(playerRank: number, opponentRank: number): number {
  return 1 / (1 + Math.pow(10, (opponentRank - playerRank) / 400));
}

/**
 * Calcule le nouveau rang après un match
 * 
 * @param currentRank - Rang actuel du joueur
 * @param opponentRank - Rang de l'adversaire
 * @param result - Résultat du match (1 victoire, 0.5 égalité, 0 défaite)
 * @returns Nouveau rang
 */
export function calculateNewRank(currentRank: number, opponentRank: number, result: number): number {
  const expectedScore = calculateWinProbability(currentRank, opponentRank);
  const newRank = currentRank + K_FACTOR * (result - expectedScore);
  return Math.round(newRank);
}

/**
 * Calcule les nouveaux rangs pour les deux joueurs après un match
 * 
 * @param winnerRank - Rang du gagnant
 * @param loserRank - Rang du perdant
 * @param isDraw - Si c'est un match nul
 * @returns Nouveaux rangs {newWinnerRank, newLoserRank}
 */
export function calculateMatchResult(
  winnerRank: number,
  loserRank: number,
  isDraw: boolean = false,
): { newWinnerRank: number; newLoserRank: number } {
  if (isDraw) {
    // En cas de match nul, les deux joueurs ont un score de 0.5
    const newWinnerRank = calculateNewRank(winnerRank, loserRank, 0.5);
    const newLoserRank = calculateNewRank(loserRank, winnerRank, 0.5);
    return { newWinnerRank, newLoserRank };
  }

  // Victoire pour le gagnant (1), défaite pour le perdant (0)
  const newWinnerRank = calculateNewRank(winnerRank, loserRank, 1);
  const newLoserRank = calculateNewRank(loserRank, winnerRank, 0);
  return { newWinnerRank, newLoserRank };
}
